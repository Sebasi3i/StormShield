"""
Great-circle distance and interpolation.

Both functions here use the same spherical-Earth convention (brief
section 7: "Use the same spherical geometry convention for segment
interpolation and distance"), with ``EARTH_RADIUS_KM`` from ``schema.py``.
"""

from __future__ import annotations

import numpy as np

from .schema import EARTH_RADIUS_KM


def haversine_distance_km(lat1, lon1, lat2, lon2):
    """Great-circle distance (km) between (lat1, lon1) and (lat2, lon2).

    Inputs are in degrees; scalars or numpy-broadcastable arrays. The
    intermediate haversine term is clipped to [0, 1] before ``arcsin``
    (per brief section 7) so floating-point overshoot at/near coincident
    points never produces a NaN or a spurious warning.
    """
    lat1_arr = np.asarray(lat1, dtype=float)
    lon1_arr = np.asarray(lon1, dtype=float)
    lat2_arr = np.asarray(lat2, dtype=float)
    lon2_arr = np.asarray(lon2, dtype=float)

    lat1_rad = np.radians(lat1_arr)
    lon1_rad = np.radians(lon1_arr)
    lat2_rad = np.radians(lat2_arr)
    lon2_rad = np.radians(lon2_arr)

    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad

    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1_rad) * np.cos(lat2_rad) * np.sin(dlon / 2.0) ** 2
    a = np.clip(a, 0.0, 1.0)
    c = 2.0 * np.arcsin(np.sqrt(a))
    distance = EARTH_RADIUS_KM * c

    scalar_inputs = (
        np.isscalar(lat1) or (hasattr(lat1, "ndim") and lat1_arr.ndim == 0)
    ) and (
        np.isscalar(lat2) or (hasattr(lat2, "ndim") and lat2_arr.ndim == 0)
    )
    if scalar_inputs and distance.ndim == 0:
        return float(distance)
    return distance


def _to_unit_vector(lat_rad, lon_rad):
    """Convert a scalar (lat, lon) in radians to a 3D unit vector."""
    x = np.cos(lat_rad) * np.cos(lon_rad)
    y = np.cos(lat_rad) * np.sin(lon_rad)
    z = np.sin(lat_rad)
    return np.array([x, y, z], dtype=float)


def _from_unit_vector(vec):
    """Convert a 3D unit vector back to scalar (lat, lon) in radians."""
    x, y, z = vec[0], vec[1], vec[2]
    lat_rad = np.arcsin(np.clip(z, -1.0, 1.0))
    lon_rad = np.arctan2(y, x)
    return lat_rad, lon_rad


def interpolate_great_circle(lat1, lon1, lat2, lon2, fraction):
    """Interpolate a point a given ``fraction`` of the way along the
    shortest great-circle arc from (lat1, lon1) to (lat2, lon2).

    ``fraction`` is a scalar in [0, 1]; 0 returns the start point
    exactly, 1 the end point exactly. Uses 3D unit-vector spherical
    linear interpolation (SLERP), which naturally follows the shortest
    arc and never linearly interpolates longitude across an antimeridian
    wrap the way naive lat/lon averaging would (brief section 7).
    Identical (or numerically indistinguishable) endpoints return that
    point exactly for any fraction. Antipodal endpoints have no unique
    shortest arc and raise ``ValueError``.

    Returns ``(lat, lon)`` in degrees, as plain floats.
    """
    lat1_rad, lon1_rad = np.radians(float(lat1)), np.radians(float(lon1))
    lat2_rad, lon2_rad = np.radians(float(lat2)), np.radians(float(lon2))

    v1 = _to_unit_vector(lat1_rad, lon1_rad)
    v2 = _to_unit_vector(lat2_rad, lon2_rad)

    cos_omega = float(np.clip(np.dot(v1, v2), -1.0, 1.0))
    omega = float(np.arccos(cos_omega))

    if np.isclose(omega, np.pi):
        raise ValueError(
            "interpolate_great_circle: endpoints are antipodal "
            f"((lat1, lon1)=({lat1}, {lon1}), (lat2, lon2)=({lat2}, {lon2})) "
            "-- the shortest great-circle arc between them is not unique."
        )

    f = float(fraction)

    if np.isclose(omega, 0.0):
        # Identical (or numerically indistinguishable) endpoints: every
        # fraction maps to the same point. Avoid dividing by sin(omega)=0.
        lat_out, lon_out = lat1_rad, lon1_rad
    else:
        sin_omega = np.sin(omega)
        a = np.sin((1.0 - f) * omega) / sin_omega
        b = np.sin(f * omega) / sin_omega
        interpolated = a * v1 + b * v2
        lat_out, lon_out = _from_unit_vector(interpolated)

    return float(np.degrees(lat_out)), float(np.degrees(lon_out))
