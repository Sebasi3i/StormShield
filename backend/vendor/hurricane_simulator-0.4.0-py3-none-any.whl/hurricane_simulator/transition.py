"""
Transition model: how a storm's (lat, lon, wind) evolves one time step
at a time.

V1 approach -- a **nonparametric analog / k-NN bootstrap**, a standard
lightweight technique for synthetic track generation:

1. From the historical record, build one feature vector per observation
   that has a valid "what happened next" delta: current latitude,
   longitude, wind speed, and time of year (as sin/cos of day-of-year,
   so Dec 31 and Jan 1 are neighbors).
2. Standardize those features and index them in a k-d tree.
3. To advance a synthetic storm one step: standardize its current state
   the same way, find the K most similar historical states ("analogs"),
   and randomly adopt one analog's realized (delta_lat, delta_lon,
   delta_wind) -- with a little extra Gaussian smoothing so the
   synthetic set isn't limited to literally-repeated historical deltas.

This keeps the storm on a realistic manifold (typical translation
speed, curvature, and intensification/weakening rates for a system of
that intensity, in that location, at that time of year) without hand-
coding an explicit track-steering or intensity model.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

from .data import _require_unique_storm_timestamp_keys
from .landmask import wrap_longitude_deg
from .schema import SIMULATION_STEP_HOURS, VALID_LATITUDE_RANGE, VALID_LONGITUDE_RANGE

__all__ = ["AnalogTransitionModel"]

#: The synoptic observation hours HURDAT2 (and this simulator) run on.
_SYNOPTIC_HOURS = (0, 6, 12, 18)

#: Number of nearest historical analogs to sample from at each step.
_DEFAULT_K_NEIGHBORS = 12

#: Extra Gaussian smoothing added to a sampled analog delta, as a
#: fraction of that feature's historical standard deviation. Keeps the
#: synthetic set from being limited to exactly-repeated historical
#: deltas while staying small relative to real step-to-step variability.
_SMOOTHING_FRACTION = 0.15


def _cyclical_day_of_year(timestamps: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    doy = timestamps.dt.dayofyear.to_numpy(dtype=float)
    angle = 2.0 * np.pi * doy / 365.25
    return np.sin(angle), np.cos(angle)


@dataclass
class _FeatureScaler:
    mean: np.ndarray
    std: np.ndarray

    def transform(self, X: np.ndarray) -> np.ndarray:
        return (X - self.mean) / self.std


class AnalogTransitionModel:
    """K-d-tree analog/bootstrap model over historical state -> delta
    pairs. Fit once per call to ``simulate_hurricanes`` and reused for
    every synthetic storm and step.
    """

    def __init__(
        self,
        tree: cKDTree,
        deltas: np.ndarray,
        scaler: _FeatureScaler,
        delta_std: np.ndarray,
        k_neighbors: int,
    ):
        self._tree = tree
        self._deltas = deltas  # shape (n, 3): delta_lat, delta_lon, delta_wind
        self._scaler = scaler
        self._delta_std = delta_std
        self._k = k_neighbors

    @classmethod
    def fit(cls, historical_data: pd.DataFrame, k_neighbors: int = _DEFAULT_K_NEIGHBORS) -> "AnalogTransitionModel":
        """Build the analog index from historical observations.

        Builds its own internal six-hour training view directly from
        ``storm_id``, ``timestamp``, ``latitude``, ``longitude``,
        ``max_wind_kt`` -- it does *not* reuse
        :func:`hurricane_simulator.data.prepare_historical_data`'s
        ``delta_*`` columns, because those are computed against
        whatever observations happen to be adjacent in the raw record
        (which can include off-cadence "special" fixes, e.g. a landfall
        observation at 03Z), not specifically the next *six-hour*
        observation.

        Only real six-hour transitions are fit on:

        1. Observations are restricted to the synoptic hours HURDAT2
           reports on (00/06/12/18 UTC, zero minutes/seconds) -- an
           off-cadence row is simply excluded from the pairing, so it
           can neither masquerade as a short step nor destroy an
           otherwise-clean pair that brackets it (e.g. a 03Z fix
           between 00Z and 06Z doesn't prevent 00Z-to-06Z from being
           used).
        2. A transition is kept only when both the current and next
           synoptic observation have finite lat/lon/wind within
           ``schema.VALID_LATITUDE_RANGE``/``VALID_LONGITUDE_RANGE``,
           nonnegative wind, and their timestamps differ by *exactly*
           ``schema.SIMULATION_STEP_HOURS`` -- a missing observation
           (e.g. no 06Z fix) makes the 00Z-to-12Z gap 12 hours, which
           is excluded rather than treated as one step.

        Every sampled delta therefore represents a real six-hour
        change, matching the one time step ``simulate_hurricanes``
        supports (see ``schema.SIMULATION_STEP_HOURS``).
        """
        required = ["storm_id", "timestamp", "latitude", "longitude", "max_wind_kt"]
        missing = [c for c in required if c not in historical_data.columns]
        if missing:
            raise ValueError(f"historical_data is missing required column(s) for fitting the transition model: {missing}")

        df = historical_data[required].copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        _require_unique_storm_timestamp_keys(df)
        df = df.sort_values(["storm_id", "timestamp"]).reset_index(drop=True)

        # Restrict to synoptic-cadence rows *before* pairing, so an
        # off-cadence row is excluded outright rather than corrupting
        # (or spuriously breaking) an adjacent six-hour pair.
        ts = df["timestamp"].dt
        is_synoptic = ts.hour.isin(_SYNOPTIC_HOURS) & (ts.minute == 0) & (ts.second == 0) & (ts.microsecond == 0)
        df = df.loc[is_synoptic].reset_index(drop=True)

        current_valid = (
            df["latitude"].between(*VALID_LATITUDE_RANGE)
            & df["longitude"].between(*VALID_LONGITUDE_RANGE)
            & np.isfinite(df["max_wind_kt"])
            & (df["max_wind_kt"] >= 0)
        )

        grouped = df.groupby("storm_id", sort=False)
        next_timestamp = grouped["timestamp"].shift(-1)
        next_lat = grouped["latitude"].shift(-1)
        next_lon = grouped["longitude"].shift(-1)
        next_wind = grouped["max_wind_kt"].shift(-1)

        next_valid = (
            next_timestamp.notna()
            & next_lat.between(*VALID_LATITUDE_RANGE)
            & next_lon.between(*VALID_LONGITUDE_RANGE)
            & np.isfinite(next_wind)
            & (next_wind >= 0)
        )

        dt_hours = (next_timestamp - df["timestamp"]).dt.total_seconds() / 3600.0
        exact_step = dt_hours.eq(SIMULATION_STEP_HOURS)

        # Never crosses a storm boundary: shift(-1) within a groupby is
        # NaN at each group's last row, which next_valid already excludes.
        valid = current_valid & next_valid & exact_step

        fit_df = df.loc[valid]
        if len(fit_df) < k_neighbors:
            raise ValueError(
                "Not enough clean six-hour historical transitions "
                f"({len(fit_df)}) to fit an analog model with "
                f"k_neighbors={k_neighbors}. Provide more historical "
                "storms/observations or lower k_neighbors."
            )

        sin_doy, cos_doy = _cyclical_day_of_year(fit_df["timestamp"])
        features = np.column_stack(
            [
                fit_df["latitude"].to_numpy(dtype=float),
                fit_df["longitude"].to_numpy(dtype=float),
                fit_df["max_wind_kt"].to_numpy(dtype=float),
                sin_doy,
                cos_doy,
            ]
        )
        mean = features.mean(axis=0)
        std = features.std(axis=0)
        std[std < 1e-6] = 1.0  # avoid divide-by-zero on constant columns
        scaler = _FeatureScaler(mean=mean, std=std)

        delta_lat = (next_lat - df["latitude"]).loc[valid].to_numpy(dtype=float)
        # Signed shortest-path longitude difference: a naive subtraction
        # would read a crossing of the antimeridian (e.g. -179 -> +179)
        # as a ~358-degree jump instead of the real ~2-degree change.
        delta_lon = wrap_longitude_deg((next_lon - df["longitude"]).loc[valid].to_numpy(dtype=float))
        delta_wind = (next_wind - df["max_wind_kt"]).loc[valid].to_numpy(dtype=float)
        deltas = np.column_stack([delta_lat, delta_lon, delta_wind])
        delta_std = deltas.std(axis=0)
        delta_std[delta_std < 1e-6] = 1.0

        tree = cKDTree(scaler.transform(features))
        return cls(
            tree=tree,
            deltas=deltas,
            scaler=scaler,
            delta_std=delta_std,
            k_neighbors=min(k_neighbors, len(fit_df)),
        )

    def sample_delta(
        self,
        rng: np.random.Generator,
        latitude: float,
        longitude: float,
        max_wind_kt: float,
        timestamp: pd.Timestamp,
    ) -> tuple[float, float, float]:
        """Sample one (delta_lat, delta_lon, delta_wind) analog step
        for the given current state."""
        doy = timestamp.dayofyear
        angle = 2.0 * np.pi * doy / 365.25
        query_point = self._scaler.transform(
            np.array([[latitude, longitude, max_wind_kt, np.sin(angle), np.cos(angle)]])
        )
        _, neighbor_idx = self._tree.query(query_point, k=self._k)
        neighbor_idx = np.atleast_1d(neighbor_idx[0])

        chosen = neighbor_idx[rng.integers(0, len(neighbor_idx))]
        base_delta = self._deltas[chosen]

        smoothing = rng.normal(0.0, _SMOOTHING_FRACTION * self._delta_std)
        delta_lat, delta_lon, delta_wind = base_delta + smoothing
        return float(delta_lat), float(delta_lon), float(delta_wind)
