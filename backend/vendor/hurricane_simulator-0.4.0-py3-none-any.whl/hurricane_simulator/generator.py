"""
Generate storms from a chosen starting point.

:func:`~hurricane_simulator.simulate_hurricanes` draws every storm's
starting point from the historical record. A :class:`StormGenerator`
instead starts storms where the caller says -- the "what if a storm
formed here" question behind the interactive dashboards -- and runs an
ensemble of differently-seeded tracks from that one starting condition.

It uses exactly the same analog transition model and track stepping as
``simulate_hurricanes``; only the choice of starting point differs.
Fitting (the analog model and the historical genesis region) takes a
few seconds, so fit once and generate as often as needed: generating a
storm takes milliseconds.
"""

from __future__ import annotations

import math
from typing import NamedTuple

import numpy as np
import pandas as pd

from .data import prepare_historical_data
from .genesis import GenesisRegion, GenesisSample
from .landmask import is_over_land
from .schema import (
    MAX_PHYSICAL_WIND_KT,
    SIMULATION_STEP_HOURS,
    SUMMARY_COLUMNS,
    VALID_LATITUDE_RANGE,
    VALID_LONGITUDE_RANGE,
)
from .simulator import _finalize_track_columns, _simulate_single_track, _summarize_track
from .transition import AnalogTransitionModel

__all__ = ["GeneratedEnsemble", "StormGenerator", "spawn_member_seeds"]

#: Weakest starting wind accepted: at the simulator's dissipation
#: threshold, so a storm is not over before it has taken a step.
MIN_START_WIND_KT = 20.0

#: Seeds are unsigned 32-bit integers, matching NumPy's SeedSequence.
MAX_SEED = 2**32 - 1

DEFAULT_MAX_DURATION_DAYS = 25.0


def spawn_member_seeds(base_seed: int, count: int) -> list[int]:
    """Derive ``count`` distinct member seeds from one base seed.

    Uses NumPy's recommended ``SeedSequence`` spawning rather than, say,
    ``base_seed + i``, which would correlate neighbouring members. Member
    ``i``'s seed depends only on ``base_seed`` and ``i``, so asking for
    more members extends an ensemble without changing the ones already
    there.
    """
    children = np.random.SeedSequence(base_seed).spawn(count)
    return [int(child.generate_state(1, dtype=np.uint32)[0]) for child in children]


class GeneratedEnsemble(NamedTuple):
    """Return value of :meth:`StormGenerator.generate_ensemble`."""

    #: One row per member per six-hour step (``schema.TRACK_COLUMNS``).
    tracks: pd.DataFrame
    #: One row per member (``schema.SUMMARY_COLUMNS``).
    summary: pd.DataFrame
    #: The seed each member was generated with, in member order.
    member_seeds: list[int]


class StormGenerator:
    """Generates storm tracks from a caller-chosen starting point.

    Build one with :meth:`fit`, then call :meth:`generate_track` or
    :meth:`generate_ensemble` as often as needed.
    """

    def __init__(self, transition_model: AnalogTransitionModel, genesis_region: GenesisRegion):
        self.transition_model = transition_model
        self.genesis_region = genesis_region

    @classmethod
    def fit(cls, historical_data: pd.DataFrame) -> "StormGenerator":
        """Fit the analog transition model and the historical genesis
        region from historical observations (e.g.
        :func:`hurricane_simulator.load_bundled_hurdat2`)."""
        prepared = prepare_historical_data(historical_data)
        return cls(AnalogTransitionModel.fit(prepared), GenesisRegion.fit(prepared))

    def check_start(self, latitude: float, longitude: float, max_wind_kt: float) -> None:
        """Raise ``ValueError``, with a message naming the problem, if a
        storm cannot start here: non-finite or out-of-range values, a
        point over land, or one far from anywhere an Atlantic storm has
        historically formed."""
        if not all(math.isfinite(value) for value in (latitude, longitude, max_wind_kt)):
            raise ValueError("latitude, longitude and max_wind_kt must be finite numbers.")
        if not VALID_LATITUDE_RANGE[0] <= latitude <= VALID_LATITUDE_RANGE[1]:
            raise ValueError("latitude must be between -90 and 90 degrees.")
        if not VALID_LONGITUDE_RANGE[0] <= longitude <= VALID_LONGITUDE_RANGE[1]:
            raise ValueError("longitude must be between -180 and 180 degrees.")
        if not MIN_START_WIND_KT <= max_wind_kt <= MAX_PHYSICAL_WIND_KT:
            raise ValueError(
                f"max_wind_kt must be between {MIN_START_WIND_KT:g} and {MAX_PHYSICAL_WIND_KT:g} knots."
            )
        if is_over_land(latitude, longitude):
            raise ValueError("Storms don't form over land -- pick a point over open water.")
        if not self.genesis_region.contains(latitude, longitude):
            distance = self.genesis_region.distance_to_nearest_historical_point_deg(latitude, longitude)
            raise ValueError(
                "This point is outside the historical Atlantic genesis region "
                f"({distance:.1f} deg from the nearest historical genesis "
                "location, beyond the plausible-neighbor buffer). Pick a point "
                "closer to where Atlantic storms have formed."
            )

    def generate_track(
        self,
        latitude: float,
        longitude: float,
        max_wind_kt: float,
        start_time,
        seed: int,
        *,
        storm_id: str = "GEN01",
        max_duration_days: float = DEFAULT_MAX_DURATION_DAYS,
    ) -> pd.DataFrame:
        """One storm from this starting point, with exactly this seed.

        ``start_time`` is anything ``pandas.Timestamp`` accepts; it is
        floored to the six-hourly synoptic cycle. Returns the track in
        ``schema.TRACK_COLUMNS`` order; the same inputs always return
        the same track.
        """
        latitude, longitude, max_wind_kt = float(latitude), float(longitude), float(max_wind_kt)
        self.check_start(latitude, longitude, max_wind_kt)
        seed = _check_seed(seed)
        try:
            start = pd.Timestamp(start_time)
        except (TypeError, ValueError) as exc:
            raise ValueError("start_time must be a valid date and time.") from exc
        if pd.isna(start):
            raise ValueError("start_time must be a valid date and time.")
        if not math.isfinite(max_duration_days) or max_duration_days <= 0:
            raise ValueError("max_duration_days must be positive.")

        max_steps = max(1, int(round(max_duration_days * 24.0 / SIMULATION_STEP_HOURS)))
        raw_rows = _simulate_single_track(
            storm_id,
            GenesisSample(latitude, longitude, max_wind_kt, start.floor(f"{SIMULATION_STEP_HOURS:g}h")),
            self.transition_model,
            np.random.default_rng(seed),
            SIMULATION_STEP_HOURS,
            max_steps,
        )
        return _finalize_track_columns(raw_rows)

    def generate_ensemble(
        self,
        latitude: float,
        longitude: float,
        max_wind_kt: float,
        start_time,
        seed: int,
        count: int = 10,
        *,
        storm_id_prefix: str = "GEN",
        max_duration_days: float = DEFAULT_MAX_DURATION_DAYS,
    ) -> GeneratedEnsemble:
        """``count`` storms from one starting point, member ``i`` seeded
        with ``spawn_member_seeds(seed, count)[i]``.

        Every member shares the starting position, wind and time; only
        the seed, and so the path the analog model draws, differs. That
        is the point of an ensemble: it shows the spread of outcomes from
        one starting condition. Members are named ``storm_id_prefix`` plus
        a zero-padded member number (``GEN01``, ``GEN02``, ...).
        """
        seed = _check_seed(seed)
        if isinstance(count, bool) or not isinstance(count, (int, np.integer)) or count < 1:
            raise ValueError("count must be a positive integer.")
        width = max(2, len(str(count)))
        member_seeds = spawn_member_seeds(seed, int(count))

        track_frames = []
        summary_rows = []
        for index, member_seed in enumerate(member_seeds):
            storm_id = f"{storm_id_prefix}{index + 1:0{width}d}"
            track = self.generate_track(
                latitude,
                longitude,
                max_wind_kt,
                start_time,
                member_seed,
                storm_id=storm_id,
                max_duration_days=max_duration_days,
            )
            track_frames.append(track)
            summary_rows.append(_summarize_track(storm_id, track))

        return GeneratedEnsemble(
            tracks=pd.concat(track_frames, ignore_index=True),
            summary=pd.DataFrame(summary_rows, columns=SUMMARY_COLUMNS),
            member_seeds=member_seeds,
        )


def _check_seed(seed) -> int:
    if isinstance(seed, bool) or not isinstance(seed, (int, np.integer)):
        raise ValueError("seed must be an integer.")
    if not 0 <= seed <= MAX_SEED:
        raise ValueError(f"seed must be between 0 and {MAX_SEED}.")
    return int(seed)
