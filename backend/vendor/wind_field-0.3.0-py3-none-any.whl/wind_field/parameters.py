"""
Default storm-size parameters for callers without sourced per-storm data.

``compute_property_exposure`` needs exactly one ``storm_parameters`` row
per storm (RMW, outer decay exponent, taper start, cutoff). Real,
sourced per-storm values rarely exist yet, so
:func:`default_storm_parameters` expands this package's demo/assumed set
(``schema.DEMO_STORM_PARAMETERS``) to every given storm ID. It does so
explicitly -- one visible row per storm, each labeled
``parameter_status="assumed"`` -- so the assumption shows up in the table
and in the run's ``storm_parameters_hash`` instead of being applied
silently.
"""

from __future__ import annotations

from collections.abc import Iterable

import pandas as pd

from .schema import DEMO_STORM_PARAMETERS

__all__ = ["default_storm_parameters"]


def default_storm_parameters(storm_ids: Iterable) -> pd.DataFrame:
    """Expand wind_field's demo/assumed parameter set to every given
    storm ID (brief section 5: "A supplied constant parameter set may
    be explicitly expanded to every storm and logged.").

    This is a convenience default for callers who don't have real,
    sourced per-storm size data yet -- NOT a calibrated hazard input.
    Pass your own ``storm_parameters`` DataFrame to
    :func:`~wind_field.compute_property_exposure` once you have it.
    """
    return pd.DataFrame([{"storm_id": storm_id, **DEMO_STORM_PARAMETERS} for storm_id in storm_ids])
