"""
hurricane_simulator -- a Monte Carlo synthetic tropical cyclone track
generator for the Atlantic basin.

Pipeline this package occupies (see README.md for the full writeup)::

    HURRICANE SIMULATOR  (this package)
            |
            v
    storm trajectory + intensity   (storm_id, t, lat, lon, V_max)
            |
            v
    WIND FIELD MODEL           (not part of this package)
            |
            v
    wind at each property
            |
            v
    DAMAGE MODEL                (not part of this package)
            |
            v
    insurance claims

This package is a pure hazard generator: given historical storm
observations, it produces synthetic storm tracks and a per-storm
summary. It never computes property-level wind, damage, or claims --
that separation is intentional and enforced by only exporting the
functions below.

Quick start
-----------
>>> import hurricane_simulator as hs
>>> historical = hs.load_bundled_hurdat2()  # real NOAA data, ships with the package
>>> # or: hs.load_hurdat2("path/to/a/newer/hurdat2.txt")

Storms from a starting point you choose (fit once, then generate often):

>>> generator = hs.StormGenerator.fit(historical)
>>> ensemble = generator.generate_ensemble(18.0, -62.0, 45, "2026-09-10", seed=42, count=10)
>>> tracks, summary = hs.simulate_hurricanes(historical, num_storms=1000, seed=42)

The interactive dashboards live in the repo's ``tools/`` folder, not in
this package, so importing it never loads web-server code.

Memory: importing this package loads global-land-mask's ~890 MB land/sea
raster (see ``landmask.py``). Import it only in processes that generate
storms -- a script, a background worker, or a web server that loads it on
the first generate request rather than at startup.
"""

from .data import load_bundled_hurdat2, load_hurdat2, prepare_historical_data
from .generator import GeneratedEnsemble, StormGenerator, spawn_member_seeds
from .simulator import SimulationResult, simulate_hurricanes
from .visualization import plot_simulation

__all__ = [
    "simulate_hurricanes",
    "SimulationResult",
    "load_hurdat2",
    "load_bundled_hurdat2",
    "prepare_historical_data",
    "StormGenerator",
    "GeneratedEnsemble",
    "spawn_member_seeds",
    "plot_simulation",
]

__version__ = "0.4.0"
