"""
Configuration and column-name contracts for the ``wind_field`` package.

``wind_field`` is deliberately independent of ``hurricane_simulator``: it
consumes the simulator's track output as plain data (see
``HAZARD_BOUNDARY_COLUMNS`` below, which mirrors -- but does not import --
``hurricane_simulator.schema.HAZARD_BOUNDARY_COLUMNS``) and never imports
from that package. This keeps the module boundary the StormShield brief
calls for: this package computes wind exposure only, and nothing here
knows the simulator exists.

As with ``hurricane_simulator.schema``, this module is the single source
of truth for column names and tunable constants used throughout the
package.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Physical / geometric constants
# ---------------------------------------------------------------------------

#: Mean Earth radius (km), IUGG value -- used for haversine distance and
#: great-circle interpolation. Matches the value used elsewhere in the
#: StormShield codebase so the two packages' geometry agree numerically.
EARTH_RADIUS_KM = 6371.0088

#: Exact knots-to-mph conversion (1 nautical mile = 1852 m exactly;
#: 1 mile = 1609.344 m exactly).
KT_TO_MPH = 1852.0 / 1609.344

#: Coordinate domain this package validates against. Deliberately
#: redefined here (rather than imported) to keep this package's input
#: contract self-contained and independent of the simulator package.
VALID_LATITUDE_RANGE = (-90.0, 90.0)
VALID_LONGITUDE_RANGE = (-180.0, 180.0)

#: The only track cadence this package expects from the simulator (its
#: native synoptic step). Tracks are validated against this and any
#: unexpected larger gap is rejected rather than silently interpolated
#: across unknown missing data (per the brief's input-contract section).
EXPECTED_TRACK_STEP_HOURS = 6.0

#: Identifies the exact radial wind formula implemented in ``profile.py``.
#: Recorded in every exposure row and in run metadata so a downstream
#: consumer can detect a mismatch if the formula ever changes.
WIND_MODEL_VERSION = "symmetric_rankine_v1"

#: This prototype's exposure rows are never claimed to be empirically
#: validated hazard output -- every row is labeled with this status.
EVIDENCE_STATUS = "assumed"

#: Valid values for a storm-parameter row's ``parameter_status`` field.
VALID_PARAMETER_STATUSES = ("assumed", "sourced")

# ---------------------------------------------------------------------------
# Input schema: track table (the simulator's hazard-boundary output)
# ---------------------------------------------------------------------------

#: The minimum columns this package requires from a track table. Mirrors
#: ``hurricane_simulator.schema.HAZARD_BOUNDARY_COLUMNS`` by convention
#: (not by import) -- see the module docstring.
TRACK_REQUIRED_COLUMNS = [
    "storm_id",
    "timestamp",
    "latitude",
    "longitude",
    "max_wind_kt",
]

# ---------------------------------------------------------------------------
# Input schema: property table
# ---------------------------------------------------------------------------

PROPERTY_REQUIRED_COLUMNS = [
    "property_id",
    "latitude",
    "longitude",
]

# ---------------------------------------------------------------------------
# Input schema: storm-parameter table
# ---------------------------------------------------------------------------

STORM_PARAMETER_REQUIRED_COLUMNS = [
    "storm_id",
    "rmw_km",
    "outer_decay_exponent",
    "taper_start_km",
    "cutoff_km",
    "parameter_status",
    "source_note",
]

# ---------------------------------------------------------------------------
# Output schema: property_wind_exposure.csv
# ---------------------------------------------------------------------------

EXPOSURE_COLUMNS = [
    "storm_id",
    "property_id",
    "peak_sustained_kt",
    "peak_sustained_mph",
    "peak_gust_mph",
    "peak_sustained_time_utc",
    "peak_gust_time_utc",
    "min_sampled_center_distance_km",
    "wind_model_version",
    "evidence_status",
]

# ---------------------------------------------------------------------------
# Demo / synthetic-fixture-only parameter values
# ---------------------------------------------------------------------------
#
# These values are for deterministic tests and the labeled sample
# deliverable only. They are NOT recommended hazard parameters -- see
# section 6 of the StormShield brief ("Synthetic fixture only").

DEMO_STORM_PARAMETERS = {
    "rmw_km": 30.0,
    "outer_decay_exponent": 0.5,
    "taper_start_km": 200.0,
    "cutoff_km": 300.0,
    "parameter_status": "assumed",
    "source_note": (
        "Demo/test fixture value from the StormShield implementation "
        "brief (26 Sep 2026), section 6. Not an empirical calibration; "
        "replace with sourced or validated per-storm parameters before "
        "any real risk use."
    ),
}

#: Assumed 3-second gust factor for the labeled demo/sample deliverable
#: only (brief section 6). ``None`` (the default in ``WindFieldConfig``)
#: means "no gust conversion configured" -- gust columns are then null,
#: never silently defaulted to a factor of 1.
DEMO_GUST_FACTOR = 1.25

#: The gust duration this demo factor is understood to correspond to.
#: Not independently validated here -- just recorded in metadata
#: alongside the factor so a downstream consumer can check it against
#: their own damage-curve convention.
DEMO_GUST_DURATION_SECONDS = 3.0

# ---------------------------------------------------------------------------
# Numerical-resolution defaults (not physical calibration -- see brief
# section 7)
# ---------------------------------------------------------------------------

DEFAULT_MAX_TIME_STEP_MINUTES = 15.0
DEFAULT_MAX_SEGMENT_DISTANCE_FRACTION_RMW = 0.1

#: Reference height/exposure convention every property is evaluated at in
#: V1 -- carried in metadata per the brief's property-table section.
DEFAULT_REFERENCE_HEIGHT_M = 10.0
DEFAULT_EXPOSURE_REFERENCE = (
    "10 m unobstructed, open exposure (uniform for all properties in V1; "
    "roof height, shielding, roughness, and topographic effects are not "
    "modeled)."
)

#: One-minute sustained wind, per NOAA's documented HURDAT2 convention
#: (brief section 5, reference [1]). Recorded in metadata's
#: ``wind_averaging`` block so a downstream consumer can check
#: compatibility with their own damage curve's wind definition.
SUSTAINED_WIND_AVERAGING = "1-minute sustained"


@dataclass
class WindFieldConfig:
    """Configuration and provenance for one ``compute_property_exposure``
    run.

    Every field the StormShield brief's "Configuration and provenance"
    section (5) asks for is represented here; ``compute_property_exposure``
    copies these into the run's metadata dict verbatim, so this object
    doubles as the record of exactly how a given exposure CSV was
    produced.
    """

    #: Identifies this specific computation run (e.g. for reproducing or
    #: auditing a delivered CSV later).
    run_id: str

    #: Identifies the storm catalog (simulator output) this run consumed.
    catalog_id: str

    #: Which radial wind formula was used. Defaults to this package's
    #: current (and, for now, only) implementation.
    model_version: str = WIND_MODEL_VERSION

    #: Numerical resolution for track interpolation (brief section 7).
    #: Not a physical parameter -- see the resolution-sensitivity check
    #: in ``tests/test_wind_field.py``.
    max_time_step_minutes: float = DEFAULT_MAX_TIME_STEP_MINUTES
    max_segment_distance_fraction_rmw: float = DEFAULT_MAX_SEGMENT_DISTANCE_FRACTION_RMW

    #: Gust conversion. Both ``None`` by default: no factor configured
    #: means every ``peak_gust_mph``/``peak_gust_time_utc`` output is
    #: null, never silently substituted with sustained wind or an
    #: implied factor of 1.
    gust_factor: float | None = None
    gust_duration_seconds: float | None = None

    #: Reference height/exposure convention every property is evaluated
    #: at (brief section 5 -- V1 uses the same convention for all
    #: properties).
    reference_height_m: float = DEFAULT_REFERENCE_HEIGHT_M
    exposure_reference: str = DEFAULT_EXPOSURE_REFERENCE

    #: Free-text notes on any assumption made for this run (e.g. "used
    #: the brief's demo storm-parameter values for all storms").
    assumption_notes: str = ""

    @property
    def wind_metric(self) -> str | None:
        """Label naming the physical quantity in the ``peak_gust_mph``
        output, e.g. ``"peak_3s_gust_10m_open_terrain_mph"`` for a
        3-second gust at the default 10 m reference height.

        Downstream consumers (e.g. damage curves keyed by wind metric)
        can compare against this label instead of rebuilding it from the
        individual fields. ``None`` when no gust conversion is
        configured, since ``peak_gust_mph`` is then all-null. V1
        evaluates every property at open exposure
        (``DEFAULT_EXPOSURE_REFERENCE``), so the terrain part is always
        ``open_terrain``.
        """
        if self.gust_factor is None or self.gust_duration_seconds is None:
            return None
        return (
            f"peak_{self.gust_duration_seconds:g}s_gust_"
            f"{self.reference_height_m:g}m_open_terrain_mph"
        )

    def to_metadata_dict(self) -> dict:
        """Return this configuration as a plain, JSON-serializable dict
        for inclusion in ``wind_field_metadata.json``."""
        return {
            "run_id": self.run_id,
            "catalog_id": self.catalog_id,
            "model_version": self.model_version,
            "max_time_step_minutes": self.max_time_step_minutes,
            "max_segment_distance_fraction_rmw": self.max_segment_distance_fraction_rmw,
            "gust_factor": self.gust_factor,
            "gust_duration_seconds": self.gust_duration_seconds,
            "reference_height_m": self.reference_height_m,
            "wind_metric": self.wind_metric,
            "exposure_reference": self.exposure_reference,
            "assumption_notes": self.assumption_notes,
        }
