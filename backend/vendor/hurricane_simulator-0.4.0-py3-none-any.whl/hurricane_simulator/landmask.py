"""
Land/sea determination.

Backed by the ``global-land-mask`` package, which bundles a ~1 km
(1/120 degree) global land/sea raster and does the lookup entirely
offline (no network or shapefile download required, and no NOAA/NHC
dependency).

Memory: global-land-mask loads that whole raster (about 890 MB) the
moment it is imported, and this module imports it at load time. Run
storm generation in its own process -- a script or background worker --
rather than inside a long-lived web server process.
"""

from __future__ import annotations

import numpy as np

try:
    from global_land_mask import globe as _globe
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "The 'global-land-mask' package is required for land/sea "
        "detection. Install it with: pip install global-land-mask"
    ) from exc

__all__ = ["is_over_land", "wrap_longitude_deg"]


def wrap_longitude_deg(longitude):
    """Canonicalize longitude degree value(s) into (-180, 180].

    Also doubles as the signed shortest-path *difference* operator: if
    ``longitude`` is itself a raw difference (``lon_b - lon_a``), the
    wrapped result is the shortest signed angular distance from a to b
    -- e.g. a naive difference of +358 degrees (the "long way" around)
    wraps to -2 degrees.
    """
    lon = np.asarray(longitude, dtype=float)
    wrapped = ((lon + 180.0) % 360.0) - 180.0
    if np.isscalar(longitude) or (hasattr(longitude, "ndim") and longitude.ndim == 0):
        return float(wrapped)
    return wrapped


def is_over_land(latitude, longitude):
    """Return whether the given point(s) are over land.

    Parameters
    ----------
    latitude, longitude:
        Scalars or array-likes of equal shape, in decimal degrees
        (longitude in [-180, 180], West negative).

    Returns
    -------
    bool or numpy.ndarray of bool
        Matches the shape of the input.
    """
    lat = np.asarray(latitude, dtype=float)
    # global_land_mask expects longitude in [-180, 180]; wrap defensively.
    lon = wrap_longitude_deg(longitude)
    result = _globe.is_land(lat, lon)
    if np.isscalar(latitude) or (hasattr(latitude, "ndim") and latitude.ndim == 0):
        return bool(result)
    return result
