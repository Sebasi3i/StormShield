"""
The radial wind profile itself: a symmetric modified-Rankine-style
profile with a smooth cosine outer taper, exactly as specified in
section 6 of the StormShield implementation brief. This is an
intentionally simple, explicitly-labeled prototype -- NOAA's own wind-
field work uses a substantially richer fitted model (see the brief's
reference [3]); this module is not that, and its demo parameters
(``schema.DEMO_STORM_PARAMETERS``) are not empirical calibration.

Every public function here is a pure, vectorized numpy function: no
state, no I/O. ``exposure.py`` is the only caller.
"""

from __future__ import annotations

import numpy as np

from .schema import KT_TO_MPH


def _validate_finite_nonnegative(name, value):
    arr = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(arr)):
        raise ValueError(f"profile: '{name}' must be finite, got {value!r}.")
    if np.any(arr < 0):
        raise ValueError(f"profile: '{name}' must be nonnegative, got {value!r}.")
    return arr


def base_wind_kt(r_km, max_wind_kt, rmw_km, outer_decay_exponent):
    """Pre-taper symmetric modified-Rankine wind (kt) at radius ``r_km``.

    ``base_wind(r) = V * (r/R)``           for ``0 <= r <= R``
    ``base_wind(r) = V * (R/r)^alpha``      for ``r > R``

    where V=``max_wind_kt``, R=``rmw_km``, alpha=``outer_decay_exponent``.
    Handles ``r=0`` directly (returns 0, matching "wind peaks at R, not
    the storm center") without ever evaluating ``(R/r)`` at r=0 -- brief
    section 6 calls this out explicitly.
    """
    r = _validate_finite_nonnegative("r_km", r_km)
    v = _validate_finite_nonnegative("max_wind_kt", max_wind_kt)

    rmw = np.asarray(rmw_km, dtype=float)
    if not np.all(np.isfinite(rmw)) or np.any(rmw <= 0):
        raise ValueError(f"profile: 'rmw_km' must be finite and positive, got {rmw_km!r}.")

    alpha = np.asarray(outer_decay_exponent, dtype=float)
    if not np.all(np.isfinite(alpha)) or np.any(alpha <= 0):
        raise ValueError(
            f"profile: 'outer_decay_exponent' must be finite and positive, got {outer_decay_exponent!r}."
        )

    inside = r <= rmw

    # Never evaluate (rmw/r) at r=0: substitute rmw itself wherever we're
    # "inside" (that branch's result is discarded by np.where anyway).
    r_safe_for_outside = np.where(inside, rmw, r)
    inside_wind = v * (r / rmw)
    outside_wind = v * (rmw / r_safe_for_outside) ** alpha

    result = np.where(inside, inside_wind, outside_wind)
    if np.isscalar(r_km) and np.isscalar(max_wind_kt) and np.isscalar(rmw_km) and np.isscalar(outer_decay_exponent):
        return float(result)
    return result


def outer_taper(r_km, taper_start_km, cutoff_km):
    """Smooth raised-cosine outer taper T(r), per brief section 6.

    ``T(r) = 1``                                    for ``r <= S``
    ``T(r) = 0.5 * (1 + cos(pi * (r - S) / (C - S)))``  for ``S < r < C``
    ``T(r) = 0``                                    for ``r >= C``

    where S=``taper_start_km``, C=``cutoff_km``. Continuous at both S
    (T=1 on both sides) and C (T=0 on both sides).
    """
    r = _validate_finite_nonnegative("r_km", r_km)

    s = np.asarray(taper_start_km, dtype=float)
    c = np.asarray(cutoff_km, dtype=float)
    if not np.all(np.isfinite(s)) or np.any(s <= 0):
        raise ValueError(f"profile: 'taper_start_km' must be finite and positive, got {taper_start_km!r}.")
    if not np.all(np.isfinite(c)) or np.any(c <= s):
        raise ValueError(
            f"profile: 'cutoff_km' must be finite and greater than taper_start_km, "
            f"got cutoff_km={cutoff_km!r}, taper_start_km={taper_start_km!r}."
        )

    in_taper = (r > s) & (r < c)
    # Guard the cosine argument's denominator the same way base_wind_kt
    # guards r=0: substitute a safe value wherever we're not in this
    # branch (result discarded by np.where regardless).
    denom_safe = np.where(in_taper, c - s, 1.0)
    taper_value = 0.5 * (1.0 + np.cos(np.pi * (r - s) / denom_safe))

    result = np.where(r <= s, 1.0, np.where(r >= c, 0.0, taper_value))
    if np.isscalar(r_km) and np.isscalar(taper_start_km) and np.isscalar(cutoff_km):
        return float(result)
    return result


def sustained_wind_profile_kt(r_km, max_wind_kt, rmw_km, outer_decay_exponent, taper_start_km, cutoff_km):
    """Full sustained wind profile: ``base_wind_kt(r) * outer_taper(r)``.

    Validates that ``taper_start_km > rmw_km`` (the taper must begin
    outside the RMW) in addition to each component function's own
    validation.
    """
    rmw = np.asarray(rmw_km, dtype=float)
    s = np.asarray(taper_start_km, dtype=float)
    if not np.all(s > rmw):
        raise ValueError(
            f"profile: 'taper_start_km' ({taper_start_km!r}) must be greater than "
            f"'rmw_km' ({rmw_km!r})."
        )

    base = base_wind_kt(r_km, max_wind_kt, rmw_km, outer_decay_exponent)
    taper = outer_taper(r_km, taper_start_km, cutoff_km)
    return base * taper


def kt_to_mph(wind_kt):
    """Convert knots to mph (unit conversion only -- brief section 5:
    "Converting knots to mph changes units, not averaging duration.")."""
    wind = _validate_finite_nonnegative("wind_kt", wind_kt)
    result = wind * KT_TO_MPH
    if np.isscalar(wind_kt):
        return float(result)
    return result


def apply_gust_mph(sustained_mph, gust_factor):
    """Convert sustained wind (mph) to a gust estimate via a simple
    multiplicative factor.

    ``gust_factor`` must be finite and >= 1.0 (brief section 10: "Gust
    factor is positive and at least 1 for this simplified conversion").
    Callers are responsible for treating ``gust_factor is None`` as "no
    conversion configured" *before* calling this function -- this
    function itself never substitutes an implied factor of 1.
    """
    sustained = _validate_finite_nonnegative("sustained_mph", sustained_mph)

    factor = np.asarray(gust_factor, dtype=float)
    if not np.all(np.isfinite(factor)):
        raise ValueError(f"profile: 'gust_factor' must be finite, got {gust_factor!r}.")
    if np.any(factor < 1.0):
        raise ValueError(f"profile: 'gust_factor' must be >= 1.0, got {gust_factor!r}.")

    result = sustained * factor
    if np.isscalar(sustained_mph) and np.isscalar(gust_factor):
        return float(result)
    return result
