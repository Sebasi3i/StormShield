"""
Input validation for the ``wind_field`` package: IDs, coordinate ranges,
time ordering/cadence, missing data, and configuration/metadata checks
(brief section 4's responsibility list for this module).

Every ``validate_*`` function either returns a list of warning strings
(non-fatal issues the caller should surface, e.g. in ``result.warnings``)
or raises ``ValueError`` on a hard error. None of these functions mutate
their input.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .schema import (
    EXPECTED_TRACK_STEP_HOURS,
    PROPERTY_REQUIRED_COLUMNS,
    STORM_PARAMETER_REQUIRED_COLUMNS,
    TRACK_REQUIRED_COLUMNS,
    VALID_LATITUDE_RANGE,
    VALID_LONGITUDE_RANGE,
    VALID_PARAMETER_STATUSES,
)


def _require_columns(df: pd.DataFrame, required: list[str], *, table_name: str) -> None:
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{table_name}: missing required column(s): {missing}.")


def _check_latlon_ranges(df: pd.DataFrame, *, table_name: str, lat_col="latitude", lon_col="longitude") -> None:
    lat = df[lat_col]
    lon = df[lon_col]
    if not np.isfinite(lat.to_numpy(dtype=float)).all():
        raise ValueError(f"{table_name}: '{lat_col}' contains missing or non-finite values.")
    if not np.isfinite(lon.to_numpy(dtype=float)).all():
        raise ValueError(f"{table_name}: '{lon_col}' contains missing or non-finite values.")
    if not lat.between(*VALID_LATITUDE_RANGE).all():
        raise ValueError(f"{table_name}: '{lat_col}' has value(s) outside {VALID_LATITUDE_RANGE}.")
    if not lon.between(*VALID_LONGITUDE_RANGE).all():
        raise ValueError(f"{table_name}: '{lon_col}' has value(s) outside {VALID_LONGITUDE_RANGE}.")


def validate_tracks(tracks: pd.DataFrame) -> list[str]:
    """Validate the track table (brief section 5: "Track table").

    Hard errors (raise ``ValueError``): missing required columns,
    missing/duplicate ``(storm_id, timestamp)`` keys, non-finite or
    out-of-range coordinates, negative wind, and an unexpected gap
    between consecutive observations of the same storm (anything other
    than exactly ``EXPECTED_TRACK_STEP_HOURS``).

    Soft issues (returned as warning strings, never raised): a
    single-point track -- its footprint is instantaneous, not a full
    lifecycle (brief section 5).
    """
    _require_columns(tracks, TRACK_REQUIRED_COLUMNS, table_name="tracks")

    if tracks["storm_id"].isna().any():
        raise ValueError("tracks: 'storm_id' contains missing values.")
    if tracks["timestamp"].isna().any():
        raise ValueError("tracks: 'timestamp' contains missing (NaT) values.")

    dup_mask = tracks.duplicated(subset=["storm_id", "timestamp"], keep=False)
    if dup_mask.any():
        n_rows = int(dup_mask.sum())
        n_keys = tracks.loc[dup_mask, ["storm_id", "timestamp"]].drop_duplicates().shape[0]
        raise ValueError(
            f"tracks: {n_rows} row(s) across {n_keys} duplicate (storm_id, timestamp) "
            "key(s) -- two records can't both describe the same storm at the same instant."
        )

    _check_latlon_ranges(tracks, table_name="tracks")

    wind = tracks["max_wind_kt"]
    if not np.isfinite(wind.to_numpy(dtype=float)).all():
        raise ValueError("tracks: 'max_wind_kt' contains missing or non-finite values.")
    if (wind < 0).any():
        raise ValueError("tracks: 'max_wind_kt' contains negative value(s).")

    warnings: list[str] = []
    sorted_tracks = tracks.sort_values(["storm_id", "timestamp"])
    for storm_id, group in sorted_tracks.groupby("storm_id", sort=False):
        if len(group) == 1:
            warnings.append(
                f"tracks: storm '{storm_id}' has only a single track point -- its "
                "wind-exposure footprint is instantaneous, not a full lifecycle."
            )
            continue
        dt_hours = group["timestamp"].diff().dt.total_seconds().dropna() / 3600.0
        bad = ~np.isclose(dt_hours.to_numpy(dtype=float), EXPECTED_TRACK_STEP_HOURS)
        if bad.any():
            raise ValueError(
                f"tracks: storm '{storm_id}' has {int(bad.sum())} gap(s) between "
                f"consecutive observations that are not exactly "
                f"{EXPECTED_TRACK_STEP_HOURS} hours. wind_field does not interpolate "
                "across unexpected/unknown missing data -- fix the input track."
            )

    return warnings


def validate_properties(properties: pd.DataFrame) -> list[str]:
    """Validate the property table (brief section 5: "Property table").

    Requires unique, non-missing ``property_id`` and finite, in-range
    coordinates. No policy values are needed or checked here.
    """
    _require_columns(properties, PROPERTY_REQUIRED_COLUMNS, table_name="properties")

    if properties["property_id"].isna().any():
        raise ValueError("properties: 'property_id' contains missing values.")
    if not properties["property_id"].is_unique:
        dup_ids = properties.loc[properties["property_id"].duplicated(keep=False), "property_id"].unique()
        raise ValueError(f"properties: 'property_id' has duplicate value(s): {list(dup_ids)}.")

    _check_latlon_ranges(properties, table_name="properties")

    return []


def validate_storm_parameters(storm_parameters: pd.DataFrame, storm_ids) -> list[str]:
    """Validate the storm-parameter table (brief section 5).

    ``storm_ids`` is the set of storm IDs present in the track table --
    every one of them must have exactly one storm-parameter row; a
    missing one is a hard error (brief: "Missing parameters are errors,
    not silent defaults.").
    """
    _require_columns(storm_parameters, STORM_PARAMETER_REQUIRED_COLUMNS, table_name="storm_parameters")

    if storm_parameters["storm_id"].isna().any():
        raise ValueError("storm_parameters: 'storm_id' contains missing values.")
    if not storm_parameters["storm_id"].is_unique:
        dup_ids = storm_parameters.loc[
            storm_parameters["storm_id"].duplicated(keep=False), "storm_id"
        ].unique()
        raise ValueError(f"storm_parameters: 'storm_id' has duplicate value(s): {list(dup_ids)}.")

    required_ids = set(storm_ids)
    present_ids = set(storm_parameters["storm_id"])
    missing_ids = required_ids - present_ids
    if missing_ids:
        raise ValueError(
            f"storm_parameters: missing parameter row(s) for storm_id(s) present in "
            f"tracks: {sorted(missing_ids)}."
        )

    numeric_cols = ["rmw_km", "outer_decay_exponent", "taper_start_km", "cutoff_km"]
    for col in numeric_cols:
        values = storm_parameters[col].to_numpy(dtype=float)
        if not np.isfinite(values).all():
            raise ValueError(f"storm_parameters: '{col}' contains missing or non-finite values.")
        if (values <= 0).any():
            raise ValueError(f"storm_parameters: '{col}' must be strictly positive.")

    if not (storm_parameters["taper_start_km"] > storm_parameters["rmw_km"]).all():
        raise ValueError("storm_parameters: 'taper_start_km' must be greater than 'rmw_km' for every storm.")
    if not (storm_parameters["cutoff_km"] > storm_parameters["taper_start_km"]).all():
        raise ValueError("storm_parameters: 'cutoff_km' must be greater than 'taper_start_km' for every storm.")

    bad_status = ~storm_parameters["parameter_status"].isin(VALID_PARAMETER_STATUSES)
    if bad_status.any():
        raise ValueError(
            f"storm_parameters: 'parameter_status' must be one of {VALID_PARAMETER_STATUSES}; "
            f"found invalid value(s): {list(storm_parameters.loc[bad_status, 'parameter_status'].unique())}."
        )

    empty_note = storm_parameters["source_note"].isna() | (storm_parameters["source_note"].astype(str).str.strip() == "")
    if empty_note.any():
        bad_storms = list(storm_parameters.loc[empty_note, "storm_id"])
        raise ValueError(
            f"storm_parameters: 'source_note' is required (even for assumed values) but is "
            f"missing/empty for storm_id(s): {bad_storms}."
        )

    return []


def validate_gust_config(gust_factor, gust_duration_seconds) -> list[str]:
    """Validate the (optional) gust conversion configuration.

    ``gust_factor is None`` is valid and means "no conversion configured"
    -- a no-op. Otherwise ``gust_factor`` must be finite and >= 1.0, and
    ``gust_duration_seconds`` must be a finite, positive number (brief
    section 10: "reject nonfinite values and missing duration when a
    factor is supplied").
    """
    if gust_factor is None:
        return []

    if not np.isfinite(gust_factor):
        raise ValueError(f"gust_factor must be finite, got {gust_factor!r}.")
    if gust_factor < 1.0:
        raise ValueError(f"gust_factor must be >= 1.0, got {gust_factor!r}.")

    if gust_duration_seconds is None or not np.isfinite(gust_duration_seconds) or gust_duration_seconds <= 0:
        raise ValueError(
            "gust_duration_seconds must be a finite, positive number when gust_factor "
            f"is supplied; got {gust_duration_seconds!r}."
        )

    return []


def validate_config(config) -> list[str]:
    """Validate the numerical-resolution fields of a ``WindFieldConfig``."""
    if not np.isfinite(config.max_time_step_minutes) or config.max_time_step_minutes <= 0:
        raise ValueError(
            f"config.max_time_step_minutes must be finite and positive, got "
            f"{config.max_time_step_minutes!r}."
        )
    if (
        not np.isfinite(config.max_segment_distance_fraction_rmw)
        or config.max_segment_distance_fraction_rmw <= 0
    ):
        raise ValueError(
            "config.max_segment_distance_fraction_rmw must be finite and positive, got "
            f"{config.max_segment_distance_fraction_rmw!r}."
        )
    return []
