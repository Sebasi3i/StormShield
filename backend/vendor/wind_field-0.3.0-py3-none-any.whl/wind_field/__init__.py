"""
wind_field: property-level wind exposure from storm tracks.

```text
HURRICANE SIMULATOR   (separate package -- not imported by this one)
        |
        v
storm trajectory + intensity     storm_id, timestamp, lat, lon, max_wind_kt
        |
        v
WIND FIELD MODEL              (this package)
        |
        v
peak wind at each property     property_wind_exposure.csv
        |
        v
DAMAGE MODEL                  (not part of this package -- Developer 1)
        |
        v
insurance claims               (not part of this package -- Developer 2)
```

This package computes **wind exposure only**. It never imports or
references insurance policies, upgrades, damage curves, annual event
rates, or dollar values -- every one of those belongs downstream, in
code that *consumes* ``compute_property_exposure``'s output. That
boundary is enforced by what this module exports: extend the wind model
itself in ``profile.py``/``geometry.py``/``exposure.py``, and put
anything damage- or claims-related in its own package instead.

``wind_field`` is intentionally independent of ``hurricane_simulator``:
it takes the simulator's track table as plain input data and never
imports from that package (see ``schema.py``'s module docstring).

Quick start
-----------

```python
from wind_field import WindFieldConfig, compute_property_exposure, default_storm_parameters

config = WindFieldConfig(
    run_id="demo-001",
    catalog_id="synthetic-catalog-v1",
    gust_factor=1.25,             # omit to leave peak_gust_mph null
    gust_duration_seconds=3.0,
)
storm_parameters = default_storm_parameters(tracks["storm_id"].unique())  # assumed sizes
result = compute_property_exposure(tracks, properties, storm_parameters, config)

config.wind_metric   # "peak_3s_gust_10m_open_terrain_mph" -- what peak_gust_mph measures

result.exposures     # DataFrame, one row per (storm_id, property_id)
result.metadata       # dict, ready for json.dump() -> wind_field_metadata.json
result.warnings       # list[str], e.g. single-point-track notices
```

See the StormShield implementation brief (26 Sep 2026), sections 4-11,
for the full specification this package implements, and
``examples/run_wind_exposure.py`` for an end-to-end sample run.
"""

from __future__ import annotations

from .exposure import ExposureResult, compute_property_exposure
from .parameters import default_storm_parameters
from .geometry import haversine_distance_km, interpolate_great_circle
from .profile import (
    apply_gust_mph,
    base_wind_kt,
    kt_to_mph,
    outer_taper,
    sustained_wind_profile_kt,
)
from .schema import (
    DEMO_GUST_DURATION_SECONDS,
    DEMO_GUST_FACTOR,
    DEMO_STORM_PARAMETERS,
    EARTH_RADIUS_KM,
    EVIDENCE_STATUS,
    EXPECTED_TRACK_STEP_HOURS,
    EXPOSURE_COLUMNS,
    KT_TO_MPH,
    PROPERTY_REQUIRED_COLUMNS,
    STORM_PARAMETER_REQUIRED_COLUMNS,
    TRACK_REQUIRED_COLUMNS,
    VALID_LATITUDE_RANGE,
    VALID_LONGITUDE_RANGE,
    WIND_MODEL_VERSION,
    WindFieldConfig,
)
from .validation import (
    validate_config,
    validate_gust_config,
    validate_properties,
    validate_storm_parameters,
    validate_tracks,
)

__all__ = [
    # Orchestration
    "compute_property_exposure",
    "ExposureResult",
    "WindFieldConfig",
    "default_storm_parameters",
    # Geometry
    "haversine_distance_km",
    "interpolate_great_circle",
    # Radial wind profile
    "base_wind_kt",
    "outer_taper",
    "sustained_wind_profile_kt",
    "kt_to_mph",
    "apply_gust_mph",
    # Validation
    "validate_tracks",
    "validate_properties",
    "validate_storm_parameters",
    "validate_gust_config",
    "validate_config",
    # Schema / constants
    "TRACK_REQUIRED_COLUMNS",
    "PROPERTY_REQUIRED_COLUMNS",
    "STORM_PARAMETER_REQUIRED_COLUMNS",
    "EXPOSURE_COLUMNS",
    "VALID_LATITUDE_RANGE",
    "VALID_LONGITUDE_RANGE",
    "EXPECTED_TRACK_STEP_HOURS",
    "EARTH_RADIUS_KM",
    "KT_TO_MPH",
    "WIND_MODEL_VERSION",
    "EVIDENCE_STATUS",
    "DEMO_STORM_PARAMETERS",
    "DEMO_GUST_FACTOR",
    "DEMO_GUST_DURATION_SECONDS",
]

__version__ = "0.3.0"
