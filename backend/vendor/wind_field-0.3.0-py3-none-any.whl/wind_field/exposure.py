"""
Per-(storm, property) peak wind exposure aggregation -- the top-level
entry point of the ``wind_field`` package (brief sections 7-9).

``compute_property_exposure`` is the only function most callers need:
it validates every input, then for each storm independently (i) builds
a resolution-controlled set of interpolated evaluation points along the
storm's track, (ii) at each point, vectorizes the radial wind profile
across every property, and (iii) maintains running per-property maxima
rather than retaining every time/property combination in memory (brief
section 9).

Wind only. This module never imports or references insurance policies,
damage curves, annual rates, or dollar values -- see the package
docstring in ``__init__.py``.
"""

from __future__ import annotations

import hashlib
import math
from typing import NamedTuple

import numpy as np
import pandas as pd

from .geometry import haversine_distance_km, interpolate_great_circle
from .profile import apply_gust_mph, kt_to_mph, sustained_wind_profile_kt
from .schema import (
    EVIDENCE_STATUS,
    EXPOSURE_COLUMNS,
    SUSTAINED_WIND_AVERAGING,
    WindFieldConfig,
)
from .validation import (
    validate_config,
    validate_gust_config,
    validate_properties,
    validate_storm_parameters,
    validate_tracks,
)


class ExposureResult(NamedTuple):
    """Return type of :func:`compute_property_exposure`."""

    exposures: pd.DataFrame
    metadata: dict
    warnings: list[str]


def _hash_dataframe(df: pd.DataFrame) -> str:
    """A short, stable content hash of a DataFrame, for recording in run
    metadata (e.g. so a delivered CSV can later be traced back to the
    exact storm-parameter table that produced it)."""
    row_hash = pd.util.hash_pandas_object(df, index=False).to_numpy()
    return hashlib.sha256(row_hash.tobytes()).hexdigest()[:16]


def _build_evaluation_points(track: pd.DataFrame, rmw_km: float, config: WindFieldConfig):
    """Return a list of ``(timestamp, lat, lon, wind_kt)`` evaluation
    points along one storm's track, at a resolution controlled by
    ``config`` (brief section 7).

    ``track`` must already be sorted by ``timestamp`` and contain at
    least one row. A single-point track returns just that one point
    (with a warning about this already surfaced by ``validate_tracks``).
    Shared endpoints between adjacent segments are included exactly
    once.
    """
    n = len(track)
    if n == 1:
        row = track.iloc[0]
        return [(row["timestamp"], float(row["latitude"]), float(row["longitude"]), float(row["max_wind_kt"]))]

    points: list[tuple] = []
    for i in range(n - 1):
        row0 = track.iloc[i]
        row1 = track.iloc[i + 1]

        segment_minutes = (row1["timestamp"] - row0["timestamp"]).total_seconds() / 60.0
        segment_distance_km = haversine_distance_km(
            row0["latitude"], row0["longitude"], row1["latitude"], row1["longitude"]
        )

        n_time = math.ceil(segment_minutes / config.max_time_step_minutes)
        n_dist = math.ceil(segment_distance_km / (config.max_segment_distance_fraction_rmw * rmw_km))
        n_sub = max(n_time, n_dist, 1)

        # Deduplicate shared endpoints: every segment after the first
        # skips its own fraction=0 point, which is identical to the
        # previous segment's fraction=1 point.
        start_index = 0 if i == 0 else 1

        for j in range(start_index, n_sub + 1):
            frac = j / n_sub
            lat, lon = interpolate_great_circle(
                row0["latitude"], row0["longitude"], row1["latitude"], row1["longitude"], frac
            )
            wind = float(row0["max_wind_kt"]) + frac * (float(row1["max_wind_kt"]) - float(row0["max_wind_kt"]))
            timestamp = row0["timestamp"] + pd.Timedelta(minutes=frac * segment_minutes)
            points.append((timestamp, lat, lon, wind))

    return points


def compute_property_exposure(
    tracks: pd.DataFrame,
    properties: pd.DataFrame,
    storm_parameters: pd.DataFrame,
    config: WindFieldConfig,
) -> ExposureResult:
    """Compute peak modeled wind exposure at every property for every
    storm (brief sections 4-9).

    Returns an :class:`ExposureResult` with:

    - ``exposures``: one row per ``(storm_id, property_id)`` pair (always
      -- a distant, always-zero-wind property still gets an explicit row),
      with the columns in ``schema.EXPOSURE_COLUMNS``. The two time
      columns are ``pandas`` ``Timestamp`` values (``NaT`` when gust
      conversion isn't configured); format them as ISO 8601 strings when
      writing to CSV.
    - ``metadata``: a plain, JSON-serializable dict for
      ``wind_field_metadata.json``.
    - ``warnings``: every non-fatal issue surfaced during validation
      (e.g. a single-point track).

    All inputs are validated up front (brief: "Return errors identifying
    invalid storms/properties before exporting an incomplete run") --
    nothing is written or returned partially on a validation failure.
    """
    all_warnings: list[str] = []

    # Declared UTC convention (brief section 5): coerce to a real
    # datetime dtype up front, on a copy, so a caller's tracks frame is
    # never mutated and so every downstream ``.dt`` operation is safe
    # regardless of how the caller's timestamp column arrived.
    tracks = tracks.copy()
    tracks["timestamp"] = pd.to_datetime(tracks["timestamp"])

    all_warnings += validate_config(config)
    all_warnings += validate_tracks(tracks)
    all_warnings += validate_properties(properties)
    all_warnings += validate_storm_parameters(storm_parameters, storm_ids=tracks["storm_id"].unique())
    all_warnings += validate_gust_config(config.gust_factor, config.gust_duration_seconds)

    tracks_sorted = tracks.sort_values(["storm_id", "timestamp"]).reset_index(drop=True)
    storm_ids_in_order = tracks_sorted["storm_id"].unique()

    params_by_storm = storm_parameters.set_index("storm_id")

    property_ids = properties["property_id"].to_numpy()
    property_lat = properties["latitude"].to_numpy(dtype=float)
    property_lon = properties["longitude"].to_numpy(dtype=float)
    n_properties = len(properties)

    gust_configured = config.gust_factor is not None

    per_storm_frames: list[pd.DataFrame] = []

    for storm_id in storm_ids_in_order:
        track = tracks_sorted.loc[tracks_sorted["storm_id"] == storm_id].reset_index(drop=True)
        params = params_by_storm.loc[storm_id]
        rmw_km = float(params["rmw_km"])
        alpha = float(params["outer_decay_exponent"])
        taper_start_km = float(params["taper_start_km"])
        cutoff_km = float(params["cutoff_km"])

        points = _build_evaluation_points(track, rmw_km, config)

        # Initialize running state from the storm's first evaluation
        # point -- including when its wind is zero, so a zero-wind tie
        # correctly resolves to the storm's first track time without a
        # separate NaT-detection pass afterward.
        first_ts, first_lat, first_lon, first_wind = points[0]
        r_km = haversine_distance_km(property_lat, property_lon, first_lat, first_lon)
        peak_sustained_kt = sustained_wind_profile_kt(r_km, first_wind, rmw_km, alpha, taper_start_km, cutoff_km)
        peak_sustained_kt = np.broadcast_to(peak_sustained_kt, (n_properties,)).astype(float).copy()
        peak_sustained_time = np.full(n_properties, first_ts.to_datetime64(), dtype="datetime64[ns]")
        min_distance_km = np.asarray(r_km, dtype=float).copy()
        if min_distance_km.shape == ():
            min_distance_km = np.full(n_properties, float(min_distance_km))

        for timestamp, lat, lon, wind in points[1:]:
            r_km = haversine_distance_km(property_lat, property_lon, lat, lon)
            wind_kt = sustained_wind_profile_kt(r_km, wind, rmw_km, alpha, taper_start_km, cutoff_km)

            mask = wind_kt > peak_sustained_kt
            peak_sustained_kt = np.where(mask, wind_kt, peak_sustained_kt)
            peak_sustained_time = np.where(mask, timestamp.to_datetime64(), peak_sustained_time)
            min_distance_km = np.minimum(min_distance_km, r_km)

        peak_sustained_mph = kt_to_mph(peak_sustained_kt)

        if gust_configured:
            peak_gust_mph = apply_gust_mph(peak_sustained_mph, config.gust_factor)
            peak_gust_time = peak_sustained_time.copy()
        else:
            peak_gust_mph = np.full(n_properties, np.nan)
            peak_gust_time = np.full(n_properties, np.datetime64("NaT"), dtype="datetime64[ns]")

        frame = pd.DataFrame(
            {
                "storm_id": storm_id,
                "property_id": property_ids,
                "peak_sustained_kt": peak_sustained_kt,
                "peak_sustained_mph": peak_sustained_mph,
                "peak_gust_mph": peak_gust_mph,
                "peak_sustained_time_utc": pd.to_datetime(peak_sustained_time),
                "peak_gust_time_utc": pd.to_datetime(peak_gust_time),
                "min_sampled_center_distance_km": min_distance_km,
                "wind_model_version": config.model_version,
                "evidence_status": EVIDENCE_STATUS,
            }
        )
        per_storm_frames.append(frame)

    exposures = pd.concat(per_storm_frames, ignore_index=True)[EXPOSURE_COLUMNS]

    metadata = config.to_metadata_dict()
    metadata["storm_parameters_hash"] = _hash_dataframe(storm_parameters)
    metadata["n_storms"] = int(len(storm_ids_in_order))
    metadata["n_properties"] = int(n_properties)
    metadata["n_rows"] = int(len(exposures))
    metadata["units"] = {
        "wind_sustained": "kt (native), mph (converted)",
        "wind_gust": "mph",
        "distance": "km",
    }
    metadata["wind_averaging"] = {
        "sustained_wind_convention": SUSTAINED_WIND_AVERAGING,
        "gust_duration_seconds": config.gust_duration_seconds,
    }
    metadata["generated_at_utc"] = pd.Timestamp.now(tz="UTC").isoformat()
    metadata["warnings"] = list(all_warnings)

    return ExposureResult(exposures=exposures, metadata=metadata, warnings=all_warnings)
